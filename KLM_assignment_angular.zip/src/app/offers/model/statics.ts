export interface Statics {
"totalRequest": number,
"status2xx": number,
"status4xx": number,
"status5xx": number
}