export class Location {
		  code: number;
		  name: string; 
		  description: string;
		  coordinates: {latitude : string;
                        longitude : string }; 

        }