import { Component } from '@angular/core';

declare var jQuery: any;
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent {
    constructor() { };
}