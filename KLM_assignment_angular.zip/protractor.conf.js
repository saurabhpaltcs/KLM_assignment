
exports.config = {
 
  baseUrl: 'http://localhost:4200/',
  
};
