package com.afkl.cases.df.vo;

public class EntityObjectAirpot implements java.io.Serializable{

	/**
	 * The serial version UID of this class. Needed for serialization.
	 */
	private static final long serialVersionUID = -4435418187728854504L;

	private Embedded _embedded;

	public Embedded get_embedded() {
		return _embedded;
	}

	public void set_embedded(Embedded _embedded) {
		this._embedded = _embedded;
	}
}
